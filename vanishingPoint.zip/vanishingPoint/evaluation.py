import os
import numpy as np
import numba
import argparse
import io
import cv2
import math
import shutil
import matplotlib.pyplot as plt
from get_annos import get_gt_label_annos, get_dt_label_annos

#obj1表示检测值，obj2表示真实值，计算两者的二维框交并比
def calc_iou(obj1, obj2):
    x_min1 = obj1[0]
    x_max1 = obj1[2]
    y_min1 = obj1[1]
    y_max1 = obj1[3]
    x_min2 = obj2[0]
    x_max2 = obj2[2]
    y_min2 = obj2[1]
    y_max2 = obj2[3]
    if x_min1 >= x_max1 or y_min1 >= y_max1 or x_min2 >= x_max2 or y_min2 >= y_max2:
        return -1.0
    if x_max1 <= x_min2 or x_max2 <= x_min1 or y_max1 <= y_min2 or y_max2 <= y_min1:
        return 0.0
    area1 = (x_max1 - x_min1) * (y_max1 - y_min1)
    area2 = (x_max2 - x_min2) * (y_max2 - y_min2)
    x_min_inter = max(x_min1, x_min2)
    x_max_inter = min(x_max1, x_max2)
    y_min_inter = max(y_min1, y_min2)
    y_max_inter = min(y_max1, y_max2)
    area_inter = (x_max_inter - x_min_inter) * (y_max_inter - y_min_inter)
    iou = area_inter / (area1 + area2 - area_inter)
    return iou


#计算二位像素下的长宽高均值(可用于检测值和真实值)
def get_hwl(t):
    x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x7, y7, x8, y8 = t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11], t[12], t[13], t[14], t[15], t[16], t[17], t[18], t[19]
    h_total = (math.sqrt((x6-y7)**2 + (y6-y7)**2) + math.sqrt((x5-x8)**2 + (y5-y8)**2) + math.sqrt((x4-x2)**2 + (y4-y2)**2) + math.sqrt(((x3-x1)**2 + (y3-y1)**2)))
    w_total = (math.sqrt((x6-y5)**2 + (y6-y5)**2) + math.sqrt((x3-x4)**2 + (y3-y4)**2) + math.sqrt((x1-x2)**2 + (y1-y2)**2) + math.sqrt(((x7-x8)**2 + (y7-y8)**2)))
    l_total = (math.sqrt((x4-y5)**2 + (y4-y5)**2) + math.sqrt((x3-x6)**2 + (y3-y6)**2) + math.sqrt((x1-x7)**2 + (y1-y7)**2) + math.sqrt(((x2-x8)**2 + (y2-y8)**2)))
    avg_h, avg_w, avg_l = h_total/4.0, w_total/4.0, l_total/4.0
    return avg_h, avg_w, avg_l


#计算总的文件的误差相似度
def compute_similarity(list_res_dict, show=True):
    count = 0
    count_list = []
    A2DS_list = []    #2D边界框相似度误差
    A3DS_list = []    #3D角点相似度误差
    AGS_list = []   #平均地面四点相似度
    ALS_list = []   #平均左侧面四点相似度
    APS_list = []   #平均前视图四点相似度
    AH_list = []
    AW_list = []
    AL_list = []
    for ind, res in enumerate(list_res_dict):
        count += 1
        count_list.append(count)
        A2DS_list.append(res['relativate_2D'])
        A3DS_list.append(res['relativate_3D'])
        AGS_list.append(res['relative_ground'])
        ALS_list.append(res['relative_left'])
        APS_list.append(res['relative_pre'])
        AH_list.append(res['relative_H'])    
        AW_list.append(res['relative_W'])
        AL_list.append(res['relative_L'])
    A2DS = np.sum(np.array(A2DS_list)) / count
    A3DS = np.sum(np.array(A3DS_list)) / count
    AGS = np.sum(np.array(AGS_list)) / count
    ALS = np.sum(np.array(ALS_list)) / count
    APS = np.sum(np.array(APS_list)) / count
    AH = np.sum(np.array(AH_list)) / count
    AW = np.sum(np.array(AW_list)) / count
    AL = np.sum(np.array(AL_list)) / count


    #绘制误差统计图
    if show:
        plt.figure(1)
        ax1 = plt.subplot(3, 1, 1)
        plt.sca(ax1)
        plt.plot(count_list, A2DS_list, 'r', alpha=1, linewidth=1, label='A2DS')
        plt.plot(count_list, A3DS_list, 'b', alpha=1, linewidth=1, label='A3DS')
        plt.legend()
        plt.xlabel('count')
        plt.ylabel('error')

        ax2 = plt.subplot(3, 1, 2)
        plt.sca(ax2)
        plt.plot(count_list, AGS_list, 'r', alpha=1, linewidth=1, label='AGS')
        plt.plot(count_list, ALS_list, 'g', alpha=1, linewidth=1, label='ALS')
        plt.plot(count_list, APS_list, 'b', alpha=1, linewidth=1, label='APS')
        plt.legend()
        plt.xlabel('count')
        plt.ylabel('error')

        ax3 = plt.subplot(3, 1, 3)
        plt.sca(ax3)
        plt.plot(count_list, AH_list, 'r', alpha=1, linewidth=1, label='AH')
        plt.plot(count_list, AW_list, 'g', alpha=1, linewidth=1, label='AW')
        plt.plot(count_list, AL_list, 'b', alpha=1, linewidth=1, label='AL')

        plt.legend()
        plt.xlabel('count')
        plt.ylabel('error')
        plt.show()
        plt.savefig('./result_img.png')
    return A2DS, A3DS, AGS, ALS, APS, AH, AW, AL





#计算检测值和真实值的相似度误差
def calc_relative_error_of_objects_Surver_ground(dt, gt):
    res_dict = {}
    #二维框边界点坐标(xmin, ymin, xmax, ymax)
    dt_2D = [[dt[0], dt[1]], [dt[2], dt[3]]]
    gt_2D = [[gt[0], gt[1]], [gt[2], gt[3]]]
    dt_2D, gt_2D = np.array(dt_2D), np.array(gt_2D)
    dist_points_dt_gt_2D = np.linalg.norm(dt_2D[0:3:1, :]-gt_2D[0:3:1, :])
    res_dict['relativate_2D'] = np.minimum(1.0, dist_points_dt_gt_2D/np.linalg.norm(gt_2D))

    #三维框八角点坐标(e1, e2, e3, e4, e5, e6, e7, e8)
    dt_3D= [[dt[4], dt[5]], [dt[6], dt[7]], [dt[8], dt[9]], [dt[10], dt[11]], [dt[12], dt[13]], [dt[14], dt[15]], [dt[16], dt[17]], [dt[18], dt[19]]]
    gt_3D= [[gt[4], gt[5]], [gt[6], gt[7]], [gt[8], gt[9]], [gt[10], gt[11]], [gt[12], gt[13]], [gt[14], gt[15]], [gt[16], gt[17]], [gt[18], gt[19]]]
    dt_3D, gt_3D = np.array(dt_3D), np.array(gt_3D)
    dist_points_dt_gt_3D = np.linalg.norm(dt_3D[0:3:1, :]-gt_3D[0:3:1, :])
    res_dict['relativate_3D'] = np.minimum(1.0, dist_points_dt_gt_3D/np.linalg.norm(gt_3D))

    #三维框下底面四点相似度(e3, e4, e5, e6)
    dt_ground = [[dt[8], dt[9]], [dt[10], dt[11]], [dt[12], dt[13]], [dt[14], dt[15]]]
    gt_ground = [[gt[8], gt[9]], [gt[10], gt[11]], [gt[12], gt[13]], [gt[14], gt[15]]]
    dt_ground, gt_ground = np.array(dt_ground), np.array(gt_ground)
    delta_ground = np.linalg.norm(gt_ground- dt_ground)
    res_dict['relative_ground'] = np.minimum(1.0, delta_ground / np.linalg.norm(gt_ground))

    #三维框左侧面四面相似度(e1, e3, e6, e7)
    dt_left = [[dt[4], dt[5]], [dt[8], dt[9]], [dt[14], dt[15]], [dt[16], dt[17]]]
    gt_left = [[gt[4], gt[5]], [gt[8], gt[9]], [gt[14], gt[15]], [gt[16], gt[17]]]
    dt_left, gt_left = np.array(dt_left), np.array(gt_left)
    delta_left = np.linalg.norm(gt_left- dt_left)
    res_dict['relative_left'] = np.minimum(1.0, delta_left / np.linalg.norm(gt_left))

    #三维框前视图四面相似度(e1, e2, e3, e4)
    dt_pre = [[dt[4], dt[5]], [dt[6], dt[7]], [dt[8], dt[9]], [dt[10], dt[11]]]
    gt_pre = [[gt[4], gt[5]], [gt[6], gt[7]], [gt[8], gt[9]], [gt[10], gt[11]]]
    dt_pre, gt_pre = np.array(dt_pre), np.array(gt_pre)
    delta_pre = np.linalg.norm(gt_pre- dt_pre)
    res_dict['relative_pre'] = np.minimum(1.0, delta_pre / np.linalg.norm(gt_pre))

    #二维像素坐标下的h, w, l
    #h是(e6, e7), (e3, e1), (e4, e2), (e5, e8)距离总和的平均值
    #w是(e5, e6), (e3, e4), (e1, e2), (e7, e8)距离总和的平均值
    #l是(e4, e5), (e3, e6), (e2, e8), (e1, e7)距离总和的平均值
    dt_avg_h, dt_avg_w, dt_avg_l =  get_hwl(dt) 
    gt_avg_h, gt_avg_w, gt_avg_l =  get_hwl(gt) 
    res_dict['relative_H'] = np.minimum(1.0, math.fabs(gt_avg_h - dt_avg_h)/gt_avg_h)
    res_dict['relative_W'] = np.minimum(1.0, math.fabs(gt_avg_w - dt_avg_w)/gt_avg_w)
    res_dict['relative_L'] = np.minimum(1.0, math.fabs(gt_avg_l - dt_avg_l)/gt_avg_l)

    return res_dict


#每个文件里的误差
def calc_relative_error(img_path, dt_annos_list, gt_annos_list, iou_thres=0.5):
    print(len(dt_annos_list), len(gt_annos_list))
    img = cv2.imread(img_path)
    img = cv2.resize(img, (1024, 512))
    table_iou = [[calc_iou(dt, gt) for gt in gt_annos_list] for dt in dt_annos_list]

    list_res_dict = []
    allcount = 0
    for i in range(len(dt_annos_list)):
        iou_max = max(table_iou[i][:])

        #找到检测框和真实框交并比>0.5的
        if iou_max > float(iou_thres):
            ind_max = table_iou[i][:].index(iou_max)
            col = [row[ind_max] for row in table_iou]
            iou_max_inv = max(col)
            ind_max_inv = col.index(iou_max_inv)
            if i == ind_max_inv:
                # print(dt_annos_list[i], gt_annos_list[ind_max])
                # #rt表示误差，res_dict表示检测信息
                res_dict = calc_relative_error_of_objects_Surver_ground(dt_annos_list[i], gt_annos_list[ind_max])
                list_res_dict.append(res_dict)
                allcount += 1

    return allcount, list_res_dict



def evaluate():
    img_dir, denorm_dir, gt_label_dir, dt_label_dir, calib_dir, result_txt = opt.images, opt.denorm, opt.gt_label, opt.dt_label, opt.calib, opt.result  
    name_list = os.listdir(dt_label_dir)

    gt_annos = get_gt_label_annos(img_dir, denorm_dir, gt_label_dir, calib_dir, name_list)
    dt_annos = get_dt_label_annos(img_dir, dt_label_dir, name_list)   
    print(len(gt_annos), len(dt_annos))   #长度表示共有多少张检测文件
    # get_eval_result(gt_annos, dt_annos)
    assert len(gt_annos) == len(dt_annos)
    allsum = 0
    list_similarity = []
    if len(dt_annos) > 0 and len(gt_annos) > 0:
        for i in range(len(dt_annos)):
            name = name_list[i].split(".")[0]
            img_path = img_dir+name+".jpg"
            if len(dt_annos[i])>0 and len(gt_annos[i])>0:
                allcount, list_res_dict = calc_relative_error(img_path, dt_annos[i], gt_annos[i])
                allsum += allcount

                list_similarity = list_similarity + list_res_dict
        A2DS, A3DS, AGS, ALS, APS, AH, AW, AL = compute_similarity(list_similarity)
        result_str = str(A2DS)+" "+str(A3DS)+" "+str(AGS)+" "+str(ALS)+" "+str(APS)+" "+str(AH)+" "+str(AW)+" "+str(AL)+"\n"
        print(result_str)
        with open (result_txt, 'a') as f :
            f.write(result_str)
        f.close()




if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    #主要输入参数设置
    parser.add_argument('--images', type=str, default='./datasets/images/', help='images_dir')    #图片数据集
    parser.add_argument('--denorm', type=str, default='./datasets/denorm/', help='denorm_dir')    #相机内外参
    parser.add_argument('--gt-label', type=str, default='./datasets/labels/', help='ground truth')   #真实值标签文件
    parser.add_argument('--dt-label', type=str, default='./datasets/labels_det/', help='detection truth')  # 检测指标签
    parser.add_argument('--calib', type=str, default='./datasets/calibs/', help='calib')   #相机标定参数
    parser.add_argument('--result', type=str, default='./datasets/result.txt', help='error result')
    opt = parser.parse_args()

    evaluate()