import time
import cv2
import numpy as np
import os
import math
import matplotlib.pyplot as plt

classesFile = "model_us_yolov4/obj.names"
modelConfiguration = "model_us_yolov4/yolov4.cfg"
modelWeights = "model_us_yolov4/yolov4_best.weights"
classes = "car"
net_input_width = 960
net_input_height = 544
confThreshold = 0.3
nmsThreshold = 0.5
net = cv2.dnn.readNetFromDarknet(modelConfiguration, modelWeights)
net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)  # CUDA: DNN_BACKEND_CUDA
net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)       # CUDA: DNN_TARGET_CUDA


def drawPred(frame, idx, classes, classId, conf, left, top, right, bottom):
    # Draw a bounding box.
    cv2.rectangle(frame, (left, top), (right, bottom), (255, 255, 255), 3)
    label = '%.2f' % conf
    # Get the label for the class name and its confidence
    if classes:
        assert (classId < len(classes))
        label = '%s:%s-%s' % (classes[classId], label, str(idx))
    # Display the label at the top of the bounding box
    labelSize, baseLine = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    top = max(top, labelSize[1])
    cv2.rectangle(frame, (left, top - round(1.5 * labelSize[1])), (left + round(1.5 * labelSize[0]), top + baseLine),
                        (255, 255, 255), cv2.FILLED)
    cv2.putText(frame, label, (left, top), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 0), 1)

def postprocess(frame, classes, outs):
    """
    Remove the bounding boxes with low confidence using non-maximum suppression
    :param frame:
    :param classes:
    :return: outs:[507*85 =(13*13*3)*(5+80),
                2028*85=(26*26*3)*(5+80),
                8112*85=(52*52*3)*(5+80)]
                [x,y,w,h,confs,class_probs_0,class_probs_1,..,class_probs_78,class_probs_79]
    :return:
    """
    frameHeight = frame.shape[0]
    frameWidth = frame.shape[1]
    # Scan through all the bounding boxes output from the network and keep only the
    # ones with high confidence scores. Assign the box's class label as the class with the highest score.
    classIds = []
    confidences = []
    boxes = []    # bbox 2d
    list_type = []  # cls name
    nms_boxes = []
    nms_list_type = []
    nms_list_conf = []
    for out in outs:
        for detection in out:
            scores = detection[5:]
            classId = np.argmax(scores)
            confidence = scores[classId]

            if confidence > confThreshold and (classId == 0 or classId == 1 or classId == 2):
                center_x = int(detection[0] * frameWidth)
                center_y = int(detection[1] * frameHeight)
                width = int(detection[2] * frameWidth)
                height = int(detection[3] * frameHeight)
                left = int(center_x - width / 2)
                top = int(center_y - height / 2)

                classIds.append(classId)
                list_type.append(classes[classId])
                confidences.append(float(confidence))
                boxes.append([left, top, width, height])

    # Perform non maximum suppression to eliminate redundant overlapping boxes with
    # lower confidences.
    indices = cv2.dnn.NMSBoxes(boxes, confidences, confThreshold, nmsThreshold)
    cnt = 0
    for i in indices:
        cnt += 1
        #i = i[0]
        i = i
        box = boxes[i]
        left = box[0]
        top = box[1]

        # width = box[2]
        # height = box[3]
        right = left + box[2]
        bottom = top + box[3]
        nms_boxes.append([left, top, right, bottom])
        nms_list_type.append(list_type[i])
        nms_list_conf.append(confidences[i])
        drawPred(frame, cnt, classes, classIds[i], confidences[i], left, top, right, bottom)
    return nms_boxes, nms_list_type, nms_list_conf

def getOutputsNames(net):
        # Get the names of all the layers in the network
        layersNames = net.getLayerNames()
        # Get the names of the output layers, i.e. the layers with unconnected outputs
        # return [layersNames[i[0] - 1] for i in net.getUnconnectedOutLayers()]
        return [layersNames[i - 1] for i in net.getUnconnectedOutLayers()]

def cv_dnn_forward(frame):
    """
    forward
    :param frame:
    :return: outs:[507*85 =13*13*3*(5+80),
                    2028*85=26*26*3*(5+80),
                    8112*85=52*52*3*(5+80)]
    """
    # Create a 4D blob from a frame.
    blob = cv2.dnn.blobFromImage(frame, 1 / 255, (net_input_width, net_input_height), [0, 0, 0], 1,crop=False)
    # Sets the input to the network
    net.setInput(blob)
    # print(list_net[0])
    # Runs the forward pass to get output of the output layers
    outs = net.forward(getOutputsNames(net))
    # Put efficiency information. The function getPerfProfile returns the overall time for inference(t) and the timings for each of the layers(in layersTimes)
    # runtime, _ = self.net.getPerfProfile()
    return outs

def yolov4_predict(frame):
    """
    predict func
    :param frame:
    :return:
    """
    t1 = time.time()
    outs = cv_dnn_forward(frame)
    # Remove the bounding boxes with low confidence
    list_box, list_type, list_conf = postprocess(frame, classes, outs)
    t2 = time.time()

    fps = 'FPS: %.2f' % (1. / (t2 - t1))
    # label = 'Inference time: %.2f ms' % (runtime * 1000.0 / cv.getTickFrequency())
    # cv.putText(frame, label, (0, 15), cv.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255))
    # cv.putText(frame, fps, (0, 40), cv.FONT_HERSHEY_COMPLEX, 1.5, (0, 0, 255), 2)
    return frame, list_box, list_type, list_conf
    
def get_uv(x, y, z, f, a, b, H):
    u = (x*f*math.cos(b)-y*f*math.sin(b))/(x*math.cos(a)*math.sin(b) + y*math.cos(a)*math.cos(b)-z*math.sin(a) + H*math.sin(a))
    v = (-x*f*math.sin(a)*math.sin(b)-y*f*math.sin(a)*math.cos(b)-f*z*math.cos(a)+H*f*math.cos(b))/(x*math.cos(a)*math.sin(b)+y*math.cos(a)*math.cos(b)-z*math.sin(a)+H*math.sin(a))
    return int(u), int(v)

u0, v0 = 960, 540
def get_uv1(x, y, z, f, Xc, Yc, Zc, H):
    k1 = (f*Xc[0]+u0*Xc[2])*x+(f*Yc[1]+v0*Xc[2])*y +Zc[2]*z-Zc[2]*H
    print(k1)


if __name__ == "__main__":
    # frame = cv2.imread("test.jpg")
    frame = cv2.imread("test1.jpg")
    detect_frame, list_box, list_type, list_conf = yolov4_predict(frame)
    detect_frame = cv2.cvtColor(detect_frame, cv2.COLOR_BGR2RGB)

    v1 = [144.73, 34.78]
    v2 = [12183.58, 615.45]
    f = 3066.7447
    oi_v1 = math.sqrt((v1[0]-960)**2 + (v1[1]-540)**2)
    oi_v2 = math.sqrt((v2[0]-960)**2 + (v2[1]-540)**2)
    Xc = [v1[0]/oi_v1, v1[1]/oi_v1, f/oi_v1]
    Yc = [v2[0]/oi_v2, v2[1]/oi_v2, f/oi_v2]
    Zc = np.cross(Xc, Yc)
    u0, v0 = 960, 540


    # f, a, b = 3063.3656264728925, -0.04002725069931105,-0.7466144351404077   #自己算消失点和焦距
    # f, a, b = 1017.9004172612504, -0.041238011654299814,-0.7365678605410753
    # f, a, b = 1722.8996577043004, -0.09359788458148966, -0.32275085228662674
    # f, a, b = 918.7456936546059,-0.04743872846199661, -0.7892955923741974
    # f, a, b = 4.929017593594141,-1.4896028454086097, -1.2614894329720816

    
    h, l, w = 0.7, 2.5, 0.8
    H = 3.619082
    # H = 10
    O = []
    
    # s1, s2, s3, s4 = math.cos(a), math.sin(a), math.cos(b), math.sin(b)
    for i in range(len(list_box)):
        k = f*h/math.fabs(list_box[i][1]-list_box[i][3])
        u, v = int((list_box[i][0]+list_box[i][2])/2), int((list_box[i][1]+list_box[i][3])/2)
        #先求出x, y, z，即中心点的世界坐标系
        # m = np.array([[f*math.cos(b), -f*math.sin(b), 0],
        #               [f*math.sin(a)*math.sin(b), f*math.sin(a)*math.cos(b), f*math.cos(a)],
        #               [math.cos(a)*math.sin(b), math.cos(a)*math.cos(b), -math.sin(a)]])
        # n = np.array([k*u, f*H*math.cos(a)-k*v, k-H*math.sin(a)])

        m = np.array([[Xc[0]*f+Xc[2]*u0, Yc[0]*f+Yc[2]*u0, Zc[0]*f+Zc[2]*u0],
                      [Xc[1]*f+Xc[2]*v0, Yc[1]*f+Yc[2]*v0, Zc[1]*f+Zc[2]*v0],
                      [Xc[2], Yc[2], Zc[2]]])
        n = np.array([k*u+(Zc[0]*f+Zc[2]*u0)*H, k*v+(Zc[1]*f+Zc[2]*v0)*H, Zc[2]*H])
        # n = np.array([u+(Zc[0]*f+Zc[2]*u0)*H, v+(Zc[1]*f+Zc[2]*v0)*H, Zc[2]*H])
        # print(m, n)
        print('k: ', k)


        s = np.linalg.solve(m, n)
        O.append(s)
 
    # #求出8个角点的世界坐标系
    for j in range(len(O)):
        center_x, center_y, center_z = O[j][0], O[j][1], O[j][2]
        k2 = Xc[2]*center_x+Yc[2]*center_y+Zc[2]*center_z-Zc[2]*H
        print(center_x, center_y, center_z)
        print('k2: ', k2)

        # get_uv1(center_x, center_y, center_z, f, Xc, Yc, Zc, H)
        # e1 = [center_x-w / 2, center_y-l / 2, center_z+h / 2]
        # e2 = [center_x+w / 2, center_y-l / 2, center_z+h / 2]
        # e3 = [center_x+w / 2, center_y+l / 2, center_z+h / 2]
        # e4 = [center_x-w / 2, center_y+l / 2, center_z+h / 2]
        # e5 = [center_x-w / 2, center_y-l / 2, center_z-h / 2]
        # e6 = [center_x+w / 2, center_y-l / 2, center_z-h / 2]
        # e7 = [center_x+w / 2, center_y+l / 2, center_z-h / 2]
        # e8 = [center_x-w / 2, center_y+l / 2, center_z-h / 2]
        # #求出8个角点的像素坐标系
        # u1, v1 = get_uv(e1[0], e1[1], e1[2], f, a, b, H)
        # u2, v2 = get_uv(e2[0], e2[1], e2[2], f, a, b, H)
        # u3, v3 = get_uv(e3[0], e3[1], e3[2], f, a, b, H)
        # u4, v4 = get_uv(e4[0], e4[1], e4[2], f, a, b, H)
        # u5, v5 = get_uv(e5[0], e5[1], e5[2], f, a, b, H)
        # u6, v6 = get_uv(e6[0], e6[1], e6[2], f, a, b, H)
        # u7, v7 = get_uv(e7[0], e7[1], e7[2], f, a, b, H)
        # u8, v8 = get_uv(e8[0], e8[1], e8[2], f, a, b, H)
        # print(u1, u2, u3, u4, u5, u6, u7, u8)
        # cv2.line(frame, (u1, v1), (u2, v2), (255, 0, 0), 3)
        # cv2.line(frame, (u1, v1), (u4, v4), (255, 0, 0), 3)
        # cv2.line(frame, (u2, v2), (u3, v3), (255, 0, 0), 3)
        # cv2.line(frame, (u3, v3), (u4, v4), (255, 0, 0), 3)
        # cv2.line(frame, (u1, v1), (u5, v5), (255, 0, 0), 3)
        # cv2.line(frame, (u6, v6), (u2, v2), (255, 0, 0), 3)
        # cv2.line(frame, (u3, v3), (u7, v7), (255, 0, 0), 3)
        # cv2.line(frame, (u4, v4), (u8, v8), (255, 0, 0), 3)
        # cv2.line(frame, (u5, v5), (u6, v6), (255, 0, 0), 3)
        # cv2.line(frame, (u5, v5), (u8, v8), (255, 0, 0), 3)
        # cv2.line(frame, (u6, v6), (u7, v7), (255, 0, 0), 3)
        # cv2.line(frame, (u7, v7), (u8, v8), (255, 0, 0), 3)
    cv2.imshow('test1', frame)
    cv2.waitKey(0)
    # cv2.imwrite('test_x.png', frame)

        



    
    #     Zc = 1.0*f*H/math.fabs(list_box[i][3] - list_box[i][1])
    #     u, v = (list_box[i][0] + list_box[i][2])/2, (list_box[i][1] + list_box[i][3])/2
    #     Xc = Zc*(u - u0)
    #     Yc = Zc*(v - v0)
    #     x.append(Xc)
    #     y.append(Yc)
    #     z.append(Zc)
    #     R.append([Xc, Yc, 1])
    #     Z.append([Zc])
    #     label_file.write('car'+' 0 0 0 '+str(list_box[i][0])+' '+str(list_box[i][1])+' '+str(list_box[i][2])+' '+str(list_box[i][3])+' 1.3 1.7 4.28 '+str(Xc)+' '+str(Yc)+' '+str(Zc)+' 0\n')
    # label_file.close()
    # R = np.mat(R)
    # A = np.dot(np.dot(np.linalg.inv(np.dot(R.T, R)), R.T), Z)
    # A = np.array(A, dtype='float32').flatten()
    # a, b, c= A[0], A[1], A[2]
    # C = -1.0/math.sqrt(a*a + b*b+1)
    # A, B, D = -a*C, -b*C, -c*C
    # denorm_file = open("denorm.txt", 'w')
    # denorm_file.write(str(A)+' '+str(B)+' '+str(C)+' '+str(D))
    # denorm_file.close()

    # fig1 = plt.figure()
    # ax1 = plt.axes(projection='3d')
    # ax1.set_xlabel("x")
    # ax1.set_ylabel("y")
    # ax1.set_zlabel("z")
    # # ax1.grid()  # 关闭网格

    # x_p = [np.min(x), np.max(x)]
    # y_p = [np.min(y), np.max(y)]
    # x_p, y_p = np.meshgrid(x_p, y_p)
    # z_p = a * x_p + b * y_p + c

    # xx = [(np.min(x) + np.max(x)) / 2, (np.min(x) + np.max(x)) / 2 + a]
    # yy = [(np.min(y) + np.max(y)) / 2, (np.min(y) + np.max(y)) / 2 + b]
    # zz = [(np.min(z) + np.max(z)) / 2, (np.min(z) + np.max(z)) / 2 - 1]

    # x.append((np.min(x) + np.max(x)) / 2)
    # y.append((np.min(y) + np.max(y)) / 2)
    # z.append((np.min(z) + np.max(z)) / 2)
    # ax1.scatter(x, y, z, c='r', marker='o')  # 散点图
    # ax1.plot_wireframe(x_p, y_p, z_p, rstride=10, cstride=10)  # 线框图
    # ax1.plot3D(xx, yy, zz, c='b', linestyle='--')
    # plt_path="plt.png"
    # plt.title("plt")
    # plt.savefig(plt_path)
        
    

        


