import time
import cv2
import numpy as np
import os
import math
import matplotlib.pyplot as plt
import shutil

# classesFile = "model_us_yolov4/obj.names"
# modelConfiguration = "model_us_yolov4/yolov4.cfg"
# modelWeights = "model_us_yolov4/yolov4_best.weights"
classesFile = "model_yolov4_tiny/obj.names"
modelConfiguration = "model_yolov4_tiny/yolov4-tiny.cfg"
modelWeights = "model_yolov4_tiny/yolov4-tiny_best.weights"
savel_label_path = "./datasets/labels_det/"
save_img_path = "./datasets/img_det/"

# savel_label_path = "D:\\808\\datasets\\Rope3D\\validation\\calib\\lables_det\\"
# save_img_path = "D:\\808\\datasets\\Rope3D\\validation\\calib\\img_det\\"
classes = "car"
net_input_width = 960
net_input_height = 544
confThreshold = 0.3
nmsThreshold = 0.5
net = cv2.dnn.readNetFromDarknet(modelConfiguration, modelWeights)
net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)  # CUDA: DNN_BACKEND_CUDA
net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)       # CUDA: DNN_TARGET_CUDA


def drawPred(frame, idx, classes, classId, conf, left, top, right, bottom):
    # Draw a bounding box.
    cv2.rectangle(frame, (left, top), (right, bottom), (255, 255, 255), 2)
    label = '%.2f' % conf
    # Get the label for the class name and its confidence
    if classes:
        assert (classId < len(classes))
        label = '%s:%s-%s' % (classes[classId], label, str(idx))
    # Display the label at the top of the bounding box
    labelSize, baseLine = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    top = max(top, labelSize[1])
    # cv2.rectangle(frame, (left, top - round(1.5 * labelSize[1])), (left + round(1.5 * labelSize[0]), top + baseLine),
    #                     (255, 255, 255), cv2.FILLED)
    # cv2.putText(frame, label, (left, top), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 0), 1)

def postprocess(frame, classes, outs):
    """
    Remove the bounding boxes with low confidence using non-maximum suppression
    :param frame:
    :param classes:
    :return: outs:[507*85 =(13*13*3)*(5+80),
                2028*85=(26*26*3)*(5+80),
                8112*85=(52*52*3)*(5+80)]
                [x,y,w,h,confs,class_probs_0,class_probs_1,..,class_probs_78,class_probs_79]
    :return:
    """
    frameHeight = frame.shape[0]
    frameWidth = frame.shape[1]
    # Scan through all the bounding boxes output from the network and keep only the
    # ones with high confidence scores. Assign the box's class label as the class with the highest score.
    classIds = []
    confidences = []
    boxes = []    # bbox 2d
    list_type = []  # cls name
    nms_boxes = []
    nms_list_type = []
    nms_list_conf = []
    for out in outs:
        for detection in out:
            scores = detection[5:]
            classId = np.argmax(scores)
            confidence = scores[classId]

            if confidence > confThreshold and (classId == 0 or classId == 1 or classId == 2):
                center_x = int(detection[0] * frameWidth)
                center_y = int(detection[1] * frameHeight)
                width = int(detection[2] * frameWidth)
                height = int(detection[3] * frameHeight)
                left = int(center_x - width / 2)
                top = int(center_y - height / 2)

                classIds.append(classId)
                list_type.append(classes[classId])
                confidences.append(float(confidence))
                boxes.append([left, top, width, height])

    # Perform non maximum suppression to eliminate redundant overlapping boxes with
    # lower confidences.
    indices = cv2.dnn.NMSBoxes(boxes, confidences, confThreshold, nmsThreshold)
    cnt = 0
    for i in indices:
        cnt += 1
        #i = i[0]
        i = i
        box = boxes[i]
        left = box[0]
        top = box[1]

        # width = box[2]
        # height = box[3]
        right = left + box[2]
        bottom = top + box[3]
        nms_boxes.append([left, top, right, bottom])
        nms_list_type.append(list_type[i])
        nms_list_conf.append(confidences[i])
        drawPred(frame, cnt, classes, classIds[i], confidences[i], left, top, right, bottom)
    return nms_boxes, nms_list_type, nms_list_conf

def getOutputsNames(net):
        # Get the names of all the layers in the network
        layersNames = net.getLayerNames()
        # Get the names of the output layers, i.e. the layers with unconnected outputs
        # return [layersNames[i[0] - 1] for i in net.getUnconnectedOutLayers()]
        return [layersNames[i - 1] for i in net.getUnconnectedOutLayers()]

def cv_dnn_forward(frame):
    """
    forward
    :param frame:
    :return: outs:[507*85 =13*13*3*(5+80),
                    2028*85=26*26*3*(5+80),
                    8112*85=52*52*3*(5+80)]
    """
    # Create a 4D blob from a frame.
    blob = cv2.dnn.blobFromImage(frame, 1 / 255, (net_input_width, net_input_height), [0, 0, 0], 1,crop=False)
    # Sets the input to the network
    net.setInput(blob)
    # print(list_net[0])
    # Runs the forward pass to get output of the output layers
    outs = net.forward(getOutputsNames(net))
    # Put efficiency information. The function getPerfProfile returns the overall time for inference(t) and the timings for each of the layers(in layersTimes)
    # runtime, _ = self.net.getPerfProfile()
    return outs

def yolov4_predict(frame):
    """
    predict func
    :param frame:
    :return:
    """
    t1 = time.time()
    outs = cv_dnn_forward(frame)
    # Remove the bounding boxes with low confidence
    list_box, list_type, list_conf = postprocess(frame, classes, outs)
    t2 = time.time()

    fps = 'FPS: %.2f' % (1. / (t2 - t1))
    # label = 'Inference time: %.2f ms' % (runtime * 1000.0 / cv.getTickFrequency())
    # cv.putText(frame, label, (0, 15), cv.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255))
    # cv.putText(frame, fps, (0, 40), cv.FONT_HERSHEY_COMPLEX, 1.5, (0, 0, 255), 2)
    return frame, list_box, list_type, list_conf
    
def get_uv(x, y, z, f, a, b, H):
    u = (x*f*math.cos(b)-y*f*math.sin(b))/(x*math.cos(a)*math.sin(b) + y*math.cos(a)*math.cos(b)-z*math.sin(a) + H*math.sin(a))
    v = (-x*f*math.sin(a)*math.sin(b)-y*f*math.sin(a)*math.cos(b)-f*z*math.cos(a)+H*f*math.cos(b))/(x*math.cos(a)*math.sin(b)+y*math.cos(a)*math.cos(b)-z*math.sin(a)+H*math.sin(a))
    return int(u), int(v)


def ViewByOne(name, frame, f, a, b, H, l, w, h):
    # frame = cv2.imread(img_path)
    detect_frame, list_box, list_type, list_conf = yolov4_predict(frame)
    detect_frame = cv2.cvtColor(detect_frame, cv2.COLOR_BGR2RGB)


    O = []
    
    s1, s2, s3, s4 = math.cos(a), math.sin(a), math.cos(b), math.sin(b)
    for i in range(len(list_box)):
        k = f*h/math.fabs(list_box[i][1]-list_box[i][3])
        u, v = int((list_box[i][0]+list_box[i][2])/2), int((list_box[i][1]+list_box[i][3])/2)
        #先求出x, y, z，即中心点的世界坐标系
        m = np.array([[f*math.cos(b), -f*math.sin(b), 0],
                      [f*math.sin(a)*math.sin(b), f*math.sin(a)*math.cos(b), f*math.cos(a)],
                      [math.cos(a)*math.sin(b), math.cos(a)*math.cos(b), -math.sin(a)]])
        n = np.array([k*u, f*H*math.cos(a)-k*v, k-H*math.sin(a)])

        s = np.linalg.solve(m, n)
        O.append(s)

    # #求出8个角点的世界坐标系
    for j in range(len(O)):
        center_x, center_y, center_z = O[j][0], O[j][1], O[j][2]
        e1 = [center_x-w / 2, center_y-l / 2, center_z+h / 2]
        e2 = [center_x+w / 2, center_y-l / 2, center_z+h / 2]
        e3 = [center_x+w / 2, center_y+l / 2, center_z+h / 2]
        e4 = [center_x-w / 2, center_y+l / 2, center_z+h / 2]
        e5 = [center_x-w / 2, center_y-l / 2, center_z-h / 2]
        e6 = [center_x+w / 2, center_y-l / 2, center_z-h / 2]
        e7 = [center_x+w / 2, center_y+l / 2, center_z-h / 2]
        e8 = [center_x-w / 2, center_y+l / 2, center_z-h / 2]
        #求出8个角点的像素坐标系
        u1, v1 = get_uv(e1[0], e1[1], e1[2], f, a, b, H)
        u2, v2 = get_uv(e2[0], e2[1], e2[2], f, a, b, H)
        u3, v3 = get_uv(e3[0], e3[1], e3[2], f, a, b, H)
        u4, v4 = get_uv(e4[0], e4[1], e4[2], f, a, b, H)
        u5, v5 = get_uv(e5[0], e5[1], e5[2], f, a, b, H)
        u6, v6 = get_uv(e6[0], e6[1], e6[2], f, a, b, H)
        u7, v7 = get_uv(e7[0], e7[1], e7[2], f, a, b, H)
        u8, v8 = get_uv(e8[0], e8[1], e8[2], f, a, b, H)
        
        cv2.line(frame, (u1, v1), (u2, v2), (255, 0, 0), 3)
        cv2.line(frame, (u1, v1), (u4, v4), (255, 0, 0), 3)
        cv2.line(frame, (u2, v2), (u3, v3), (255, 0, 0), 3)
        cv2.line(frame, (u3, v3), (u4, v4), (255, 0, 0), 3)
        cv2.line(frame, (u1, v1), (u5, v5), (255, 0, 0), 3)
        cv2.line(frame, (u6, v6), (u2, v2), (255, 0, 0), 3)
        cv2.line(frame, (u3, v3), (u7, v7), (255, 0, 0), 3)
        cv2.line(frame, (u4, v4), (u8, v8), (255, 0, 0), 3)
        cv2.line(frame, (u5, v5), (u6, v6), (255, 0, 0), 3)
        cv2.line(frame, (u5, v5), (u8, v8), (255, 0, 0), 3)
        cv2.line(frame, (u6, v6), (u7, v7), (255, 0, 0), 3)
        cv2.line(frame, (u7, v7), (u8, v8), (255, 0, 0), 3)
        x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x7, y7, x8, y8 = str(u1), str(v1), str(u2), str(v2), str(u3), str(v3), str(u4), str(v4), str(u5), str(v5), str(u6), str(v6), str(u7), str(v7), str(u8), str(v8)
        with open(savel_label_path+name+".txt", 'a') as file:
            file.write(x1+' '+y1+' '+x2+' '+y2+' '+x3+' '+y3+' '+x4+' '+y4+' '+x5+' '+y5+' '+x6+' '+y6+' '+x7+' '+y7+' '+x8+' '+y8+'\n')
    # cv2.imshow('test1', frame)
    # cv2.waitKey(10)
    # cv2.imwrite(save_img_path+name+".jpg", frame)



if __name__ == "__main__":
    img_path = "test3.jpg"
    frame = cv2.imread(img_path)
    f, a, b = 2183.375019, -0.01919361208621163, -0.40319316660181587     #分别对应相机的焦距、两角度
    H = 5.951619124375543  
    l, w, h= 5.480000000000002, 1.0400000000000003, 1.9800000000000013
    ViewByOne("test3", frame, f, a, b, H, l, w, h)