import cv2
from PIL import Image
from PIL import ImageEnhance
import  numpy as np
from skimage import io, feature, color, transform
import matplotlib.pyplot as plt
import os
import math
import time
from viewByOne import ViewByOne
import shutil

def image_enhance(image, contrast, sharpness):
    img_contrast = ImageEnhance.Contrast(image)
    image_contrasted = img_contrast.enhance(contrast)
    # image_contrasted.show()
    img_sharp = ImageEnhance.Sharpness(image_contrasted)
    image_sharped = img_sharp.enhance(sharpness)
    # image_sharped.show()
    return image_sharped

def get_canny_edges(image, sigma):
    edges = feature.canny(color.rgb2gray(image), sigma=sigma)
    return edges

def get_hough_lines(edges, line_length, line_gap):
    lines = transform.probabilistic_hough_line(edges, line_length=line_length, line_gap=line_gap)
    return np.asarray(lines)

def visualize_inliers(image, enhanced, edges, lines, inlier_lines_list, vp1, fig_name='detected_lines.png'):
    fig, axes = plt.subplots(3, 2, figsize=(15, 15), sharex=True, sharey=True)
    ax = axes.ravel()

    # ax[0].imshow(image)
    # ax[0].set_title('Input image')
    
    ax[0].imshow(enhanced)
    ax[0].set_title('Enhanced image')
    
    ax[1].imshow(edges)
    ax[1].set_title('Canny edges')

    ax[2].imshow(edges * 0)
    for line in lines:
        p0, p1 = line
        ax[2].plot((p0[0], p1[0]), (p0[1], p1[1]))
    ax[2].set_xlim((0, image.shape[1]))
    ax[2].set_ylim((image.shape[0], 0))
    ax[2].set_title('Probabilistic Hough')

    for i in range(len(inlier_lines_list)):
        ax[i+3].imshow(edges * 0)
        for line in lines[inlier_lines_list[i]]:
            p0, p1 = line
            ax[i+3].plot((p0[0], p1[0]), (p0[1], p1[1]), (255, 255, 0))
        ax[i+3].set_xlim((0, image.shape[1]))
        ax[i+3].set_ylim((image.shape[0], 0))
        ax[i+3].set_title('RANSAC {} Inliers'.format(str(i)))


    ax[5].imshow(image)
    plt.plot([vp1[0]], [vp1[1]], ('g')+'X', markersize=8)
    ax[5].set_xlim((0, image.shape[1]))
    ax[5].set_ylim((image.shape[0], 0))
    ax[5].set_title('Vp')

    for a in ax:
        a.set_axis_off()

    plt.tight_layout()
    plt.savefig(fig_name)
    plt.close()


def read_image(path):
    image = io.imread(path)
    return image

def calculate_metric_angle(current_hypothesis, lines, ignore_pts, ransac_angle_thresh):
    current_hypothesis = current_hypothesis / current_hypothesis[-1]
    hypothesis_vp_direction = current_hypothesis[:2] - lines[:,0]
    lines_vp_direction = lines[:,1] - lines[:,0]
    magnitude = np.linalg.norm(hypothesis_vp_direction, axis=1) * np.linalg.norm(lines_vp_direction, axis=1)
    magnitude[magnitude == 0] = 1e-5
    cos_theta = (hypothesis_vp_direction*lines_vp_direction).sum(axis=-1) / magnitude
    theta = np.arccos(np.abs(cos_theta))
    inliers = (theta < ransac_angle_thresh * np.pi / 180)
    inliers[ignore_pts] = False
    return inliers, inliers.sum()

def run_line_ransac(lines, ransac_iter=3000, ransac_angle_thresh=2, ignore_pts=None):
    best_vote_count = 0
    best_inliers = None
    best_hypothesis = None
    if ignore_pts is None:
        ignore_pts = np.zeros((lines.shape[0])).astype('bool')   #根据得到的点数创建bool类型的值，表示该点是否会被忽略
        lines_to_chose = np.arange(lines.shape[0])
    else:
        lines_to_chose = np.where(ignore_pts==0)[0]
    for iter_count in range(ransac_iter):
        idx1, idx2 = np.random.choice(lines_to_chose, 2, replace=False)

        l1 = np.cross(np.append(lines[idx1][1], 1), np.append(lines[idx1][0], 1))   #返回与两个点正交的点
        l2 = np.cross(np.append(lines[idx2][1], 1), np.append(lines[idx2][0], 1))

        current_hypothesis = np.cross(l1, l2)
        # print(current_hypothesis)
        if current_hypothesis[-1] == 0:
            continue
        inliers, vote_count = calculate_metric_angle(current_hypothesis, lines, ignore_pts, ransac_angle_thresh)
        if vote_count > best_vote_count:
            best_vote_count = vote_count
            best_hypothesis = current_hypothesis
            best_inliers = inliers
    return best_hypothesis, best_inliers



def get_vp_inliers(image):
    # image = read_image(image_path)
    # cv2.imshow('frame', image)
    # cv2.waitKey(0)
    
    image_pil = Image.fromarray(image)
    print(image_pil)
    enhanced_pil = image_enhance(image_pil, contrast=5, sharpness=10)
    enhanced_ski = np.array(enhanced_pil)
    edges = get_canny_edges(enhanced_ski, sigma=5)
    lines = get_hough_lines(edges, line_length=11, line_gap=7)

    best_hypothesis_1, best_inliers_1 = run_line_ransac(lines)
    ignore_pts = best_inliers_1
    best_hypothesis_2, best_inliers_2 = run_line_ransac(lines, ignore_pts=ignore_pts)
    inlier_lines_list = [best_inliers_1, best_inliers_2]
    best_hypothesis_1 = best_hypothesis_1 / best_hypothesis_1[-1]
    best_hypothesis_2 = best_hypothesis_2 / best_hypothesis_2[-1]
    hypothesis_list = [best_hypothesis_1, best_hypothesis_2]
    viz_stuff = [image, enhanced_ski, edges, lines]
    return inlier_lines_list, hypothesis_list, viz_stuff


def determine_focal_lenth(vp1, vp2, image):
    oi = [image.shape[1] / 2, image.shape[0] / 2]
    k = (vp1[1] - vp2[1])/(vp1[0] - vp2[0])
    b = vp2[1] - k * vp2[0]
    oi_vi = math.fabs(k * oi[0] - oi[1] + b) / math.pow(k * k + 1, 0.5)
    oi_v1 = math.sqrt((vp1[1] - oi[1])**2 + (vp1[0] - oi[0])** 2)
    vi_v1 = math.sqrt(oi_v1*oi_v1 - oi_vi*oi_vi)
    v1_v2 = math.sqrt((vp1[1] - vp2[1])** 2 + (vp1[0] - vp2[0])** 2)
    vi_v2 = math.fabs(v1_v2 - vi_v1)
    f = math.sqrt(vi_v1*vi_v2)
    return f
    
def read_calib(file_path):
    text_file = open(file_path, 'r')
    for line in text_file:
        content = line.split(' ')[1]
    return float(content)

def decide_v(v0, v1):
    if v0[0] >0 and v0[0] < 1024 and v0[1] > 0 and v0[1] < 512:
        return v0
    else:
        return v1

def decide_f(f1, f2):
    print(f1, f2)
    if f1>0 and f2<0:
        return math.sqrt(f1)
    elif f1<0 and f2>0:
        return math.sqrt(f2)
    elif f1>0 and f2>0:
        if math.fabs(math.sqrt(f1)-2000) < math.fabs(math.fabs(f2)-2000):
            return math.sqrt(f1)
        else:
            return math.sqrt(f2)
    else:
        return 2183

if __name__ =="__main__":
    img_dir = "./datasets/images/"
    calib_dir = "./datasets/calibs/"
    savel_label_path = "./datasets/labels_det/"
    save_img_path = "./datasets/img_det/"
    
    img = cv2.imread('test3.jpg')
    img = cv2.resize(img, (1024, 512))
        
    inlier_lines_list, hypothesis_list, viz_stuff = get_vp_inliers(img)    #get_vp_inliers(img_path)
    image, enhanced_ski, edges, lines = viz_stuff
    v0, v1 = hypothesis_list   #两个参考点
    v = decide_v(v0, v1)   #两个点中选一个
    print(v)
    
    v[0], v[1] = 925, 39

    # H = 3.76725
    # H = 2.776954529633913
    # H = 7.56322
    l, w, h = 4.1869, 1.6910, 1.3302

    # k=823.224
    # # kl = k*8/H
    # f = 2183

    # H = k*8*f/math.sqrt((f*f+v[1]*v[1])*(f*f+v[1]*v[1]) + v[0]*v[0]*(f*f+v[1]*v[1]))
    # print(H)
    

    f = read_calib(calib_dir+"1632_YiZhuang11North_420_1612431546_1612432197_1_obstacle.txt")

    a = math.atan2(-v[1], f)
    b = math.atan2(-v[0]*math.cos(a), f)

    
    ViewByOne("1", img, f, a, b, H, l, w, h)

