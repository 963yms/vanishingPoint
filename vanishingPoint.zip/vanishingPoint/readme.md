
运行python getImageInfo.py 获取车辆尺寸均值
先运行python decide_VLH.py获取检测标签
再运行python evaluation.py进行评估