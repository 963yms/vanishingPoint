from torchvision.transforms import ToTensor
import numpy as np
from PIL import Image
from torchvision.datasets import ImageFolder
import torch
from torchvision.datasets.folder import *
from typing import *
import os
import math

# trainPath = ".\\datasets\\"
# trainLabelPath = ".\\datasets\\labels\\"

trainPath = "D:\\808\\datasets\\Rope3D\\training\\"
trainLabelPath = "D:\\808\\datasets\\Rope3D\\training\\label_2\\"

means = [0, 0, 0]
std = [0, 0, 0]
total_classes = []
detect_classes = ['car']

#重载ImageFolder方法，能指定具体的文件夹
# class FilterableImageFolder(ImageFolder):
#     def __init__(
#             self,
#             root: str,
#             transform: Optional[Callable] = None,
#             target_transform: Optional[Callable] = None,
#             loader: Callable[[str], Any] = default_loader,
#             is_valid_file: Optional[Callable[[str], bool]] = None,
#             valid_classes: List = None
#     ):
#         self.valid_classes = valid_classes
#         super(FilterableImageFolder, self).__init__(root, transform, target_transform, loader, is_valid_file)

#     def find_classes(self, directory: str) -> Tuple[List[str], Dict[str, int]]:
#         classes = sorted(entry.name for entry in os.scandir(directory) if entry.is_dir())
#         classes = [valid_class for valid_class in classes if valid_class in self.valid_classes]
#         if not classes:
#             raise FileNotFoundError(f"Couldn't find any class folder in {directory}.")

#         class_to_idx = {cls_name: i for i, cls_name in enumerate(classes)}
#         return classes, class_to_idx


#得到数据集的均值、方差以及图片的长宽
# transform = ToTensor()
# dataset_img = FilterableImageFolder(trainPath, valid_classes=['images'], transform=transform)
# for img, a in dataset_img:
#     c, img_h, img_w = img.shape
#     for i in range(3):
#         means[i] += img[i, :, :].mean()
#         std[i] += img[i, :, :].std()
# means=np.array(means)/len(dataset_img)
# std=np.array(std)/len(dataset_img)
# means, std = str(means), str(std)
# print(means, std)


kk = 0
dim = {}
depth_list=[]
for type in detect_classes:
    dim[type] = {}
    dim[type]['count'] = 0
    dim[type]['height_3d'] = 0.0
    dim[type]['width_3d'] = 0.0
    dim[type]['length_3d'] = 0.0
    dim[type]['z'] = 0.0
    dim[type]['valid_minsub_x'], dim[type]['valid_minsub_y'] = 1920.0, 1280.0
    dim[type]['invalid_minsub_x'], dim[type]['invalid_minsub_y'] = 1920.0, 1280.0
label_list = os.listdir(trainLabelPath)
# print('total: ',len(label_list))
for label in label_list:
    if label.startswith("1901_"):
        kk = kk+1
        file = open(trainLabelPath+label, "r", encoding='utf-8')
        print(kk)
        for line in file.readlines():
            curLine = line.strip().split(' ')
            type, x1, y1, x2, y2, height_3d, width_3d, length_3d, x, y, z = curLine[0],float(curLine[4]),float(curLine[5]),float(curLine[6]),float(curLine[7]) , float(curLine[8]), float(curLine[9]), float(curLine[10]), float(curLine[11]), float(curLine[12]), float(curLine[13])
            if type not in total_classes:
                total_classes.append(type)
            #计算需要检测类别的有效尺寸和深度
            if type in detect_classes:
                #数据集有效
                if height_3d>0.0 and width_3d>0.0 and length_3d>0.0:
                    dim[type]['count'] +=1
                    dim[type]['height_3d'] += height_3d
                    dim[type]['width_3d'] += width_3d
                    dim[type]['length_3d'] += length_3d
                    dim[type]['z'] += z
                    depth_list.append(z)     
                    if abs(x1 - x2) <= dim[type]['valid_minsub_x']:
                        dim[type]['valid_minsub_x'] = abs(x1-x2)
                    if abs(y1 - y2) <= dim[type]['valid_minsub_y']:
                        dim[type]['valid_minsub_y'] = abs(y1 - y2) 
                elif height_3d==0.0 and width_3d==0.0 and length_3d==0.0:
                    if abs(x1 - x2) <= dim[type]['invalid_minsub_x']:
                        dim[type]['invalid_minsub_x'] = abs(x1-x2)
                    if abs(y1 - y2) <= dim[type]['invalid_minsub_y']:
                        dim[type]['invalid_minsub_y'] = abs(y1 - y2) 
        file.close()

#有效类别总数，深度
total, depth = 0, 0.0
for _type in detect_classes:
    total += dim[_type]['count']
    # depth += dim[_type]['z']
# depth_list=np.array(depth_list)
# avg_depth, std_depth= depth/total, np.std(depth_list)


print('type: '+_type+' h: '+str(dim[_type]['height_3d']/dim[_type]['count'])+' w: '+str(dim[_type]['width_3d']/dim[_type]['count'])+' l: '+str(dim[_type]['length_3d']/dim[_type]['count'])+' z: '+str(dim[_type]['z']/dim[_type]['count']))

# f = open("imageInfo.txt", "w")
# f.write('----total_classes:\n')
# for i in total_classes:
#     f.write(i+' ')
# f.write('\n----detect_classes and total:\n')
# for _type in detect_classes:
#     f.write('type: '+_type+' '+'count: '+str(dim[_type]['count'])+'\n')
#     f.write('type: '+_type+' '+'-----valid-----'+'min_sub_x: '+str(dim[_type]['valid_minsub_x'])+' min_sub_y: '+str(dim[_type]['valid_minsub_y'])+'\n')
#     f.write('type: '+_type+' '+'-----invalid-----'+'min_sub_x: '+str(dim[_type]['invalid_minsub_x'])+' min_sub_y: '+str(dim[_type]['invalid_minsub_y'])+'\n')
# f.write('----Image_Height: '+str(img_h)+' '+'Image_Width: '+str(img_w)+'\n')
# f.write('----means: '+means+' '+'std: '+std+'\n')
# f.write('----detect_classes_avg(h, w, l, z): '+'\n')
# for _type in detect_classes:
#     f.write('type: '+_type+' h: '+str(dim[_type]['height_3d']/dim[_type]['count'])+' w: '+str(dim[_type]['width_3d']/dim[_type]['count'])+' l: '+str(dim[_type]['length_3d']/dim[_type]['count'])+' z: '+str(dim[_type]['z']/dim[_type]['count'])+'\n')
# f.write('----depth_reference:\n')
# f.write('avg_z: '+str(avg_depth)+' '+'std_z: '+str(std_depth)+'\n')
# f.close()
# print('get ImageInfo in ./config successfully! Please modify params in ./config/default.yaml and ./src/config/defaults.py.')  
